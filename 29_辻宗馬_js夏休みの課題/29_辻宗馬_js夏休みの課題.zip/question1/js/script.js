var num = 3;

for ( let i = 1; i < 11; i++){
    console.log( num ** i);
    if ( (num ** i) % 27 == 0){
        console.log;
    }else if ( (num ** i) % 9 == 0){
        console.log;
    }else if ( (num ** i) % 3 == 0){
        console.log;
    }else {
        console.log(num ** i);
    }
}

