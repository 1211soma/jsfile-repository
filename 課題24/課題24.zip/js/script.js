'use stirict';

fetch ('file:///E:/javascript%E5%AE%9F%E7%BF%92/%E8%AA%B2%E9%A1%8C24/list.html')
.then((Response) => Response.json())
.then((data) => func1(data))

.catch((err) => console.log(err));






const kiji = (data) => {

    const 











};

















